package JyNI.gc;

public interface ResurrectableGCHead extends PyObjectGCHead {
	public ResurrectableGCHead makeResurrectedHead();
}
